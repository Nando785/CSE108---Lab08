import '../styles/student.css';
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function adminHome() {
    return(
        <div>TESTING</div>
    );
}

export default adminHome;